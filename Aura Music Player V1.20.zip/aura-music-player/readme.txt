=== Aura Music Player ===
Contributors: robertshultz
Tags: music, audio, player, visualizer
Requires at least: 5.0
Tested up to: 6.7
Stable tag: 1.30
Requires PHP: 7.4
License: GPL-2.0-or-later

A beautiful 3D music player widget with audio visualizer, customizable colors, cover art, and review box.

== Description ==

Aura Music Player adds a stunning, fully customizable audio player to any WordPress page or post via a simple shortcode.

**Features:**
* 3D cover art with tilt effect
* Real-time audio frequency visualizer
* Customizable aura colors, border colors, shapes
* Light and dark background modes
* Animated radiating music notes
* Review / liner notes text box
* Drag & drop audio and cover art upload
* Share and download buttons
* Fully responsive

== Usage ==

**Block Editor (recommended):**
1. Click + to add a block
2. Search for "Aura Music Player"
3. Add the block — configure title, artist, audio file, and cover art in the sidebar

**Shortcode (classic editor / page builders):**
`[aura_player title="My Song" artist="Artist Name" src="https://example.com/song.mp3" cover="https://example.com/cover.jpg"]`

== Installation ==

1. Upload the `aura-music-player` folder to `/wp-content/plugins/`
2. Activate via Plugins menu
3. Add `[aura_player]` to any page or post
