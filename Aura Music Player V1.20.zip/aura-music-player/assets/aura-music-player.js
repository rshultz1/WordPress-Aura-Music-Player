(function(){
  "use strict";

  function initAuraPlayer(root) {
    function q(name) { return root.querySelector('[data-aura="' + name + '"]'); }
    function qa(sel) { return root.querySelectorAll(sel); }

    var audioEl       = q('audio');
    var playBtn       = q('play');
    var playIcon      = q('play-icon');
    var progressTrack = q('progress-track');
    var progressFill  = q('progress-fill');
    var curTimeEl     = q('cur-time');
    var totTimeEl     = q('tot-time');
    var volTrack      = q('vol-track');
    var volFill       = q('vol-fill');
    var muteBtn       = q('mute');
    var panelToggle   = q('panel-toggle');
    var panelBody     = q('panel-body');
    var glowEl        = q('glow');
    var playerCard    = q('card');
    var cover3D       = q('cover3d');
    var coverDisplay  = q('cover-display');
    var downloadBtn   = q('download-btn');
    var visualizerEl  = q('visualizer');
    var reviewWrap    = q('review-wrap');
    var reviewCard    = q('review-card');
    var reviewText    = q('review-text');
    var notesField    = q('notes-field');

    var isPlaying = false;
    var audioFile = null;
    var audioContext, analyser, source;
    var vizBars = [];

    /* Visualizer bars */
    for (var i = 0; i < 32; i++) {
      var bar = document.createElement('div');
      bar.className = 'aura-ap-viz-bar';
      visualizerEl.appendChild(bar);
      vizBars.push(bar);
    }

    /* Format time */
    function fmtTime(s) {
      if (isNaN(s)) return '0:00';
      var m = Math.floor(s / 60);
      var sec = Math.floor(s % 60);
      return m + ':' + (sec < 10 ? '0' : '') + sec;
    }

    /* Play / Pause */
    playBtn.addEventListener('click', function(){
      if (!audioEl.src) return;
      if (isPlaying) {
        audioEl.pause();
        playIcon.innerHTML = '<polygon points="6 3 20 12 6 21 6 3"/>';
        isPlaying = false;
        visualizerEl.classList.remove('aura-ap-active');
      } else {
        audioEl.play();
        playIcon.innerHTML = '<rect x="5" y="3" width="4" height="18"/><rect x="15" y="3" width="4" height="18"/>';
        isPlaying = true;
        visualizerEl.classList.add('aura-ap-active');
        if (!audioContext) initAudioCtx();
        animateViz();
      }
    });

    function initAudioCtx() {
      audioContext = new (window.AudioContext || window.webkitAudioContext)();
      analyser = audioContext.createAnalyser();
      analyser.fftSize = 64;
      source = audioContext.createMediaElementSource(audioEl);
      source.connect(analyser);
      analyser.connect(audioContext.destination);
    }

    function animateViz() {
      if (!isPlaying || !analyser) return;
      var data = new Uint8Array(analyser.frequencyBinCount);
      analyser.getByteFrequencyData(data);
      for (var i = 0; i < vizBars.length; i++) {
        var v = data[i] || 0;
        vizBars[i].style.height = Math.max(3, (v / 255) * 28) + 'px';
      }
      requestAnimationFrame(animateViz);
    }

    /* Progress */
    audioEl.addEventListener('timeupdate', function(){
      if (audioEl.duration) {
        progressFill.style.width = (audioEl.currentTime / audioEl.duration * 100) + '%';
        curTimeEl.textContent = fmtTime(audioEl.currentTime);
      }
    });

    audioEl.addEventListener('loadedmetadata', function(){
      totTimeEl.textContent = fmtTime(audioEl.duration);
    });

    audioEl.addEventListener('ended', function(){
      isPlaying = false;
      playIcon.innerHTML = '<polygon points="6 3 20 12 6 21 6 3"/>';
      visualizerEl.classList.remove('aura-ap-active');
    });

    progressTrack.addEventListener('click', function(e){
      if (!audioEl.duration) return;
      var r = progressTrack.getBoundingClientRect();
      audioEl.currentTime = ((e.clientX - r.left) / r.width) * audioEl.duration;
    });

    /* Volume */
    var vol = 0.7;
    volTrack.addEventListener('click', function(e){
      var r = volTrack.getBoundingClientRect();
      vol = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width));
      audioEl.volume = vol;
      volFill.style.width = (vol * 100) + '%';
    });

    muteBtn.addEventListener('click', function(){
      audioEl.muted = !audioEl.muted;
      q('vol-icon').style.opacity = audioEl.muted ? '0.3' : '1';
    });

    /* Audio upload */
    q('audio-upload').addEventListener('click', function(){ q('audio-input').click(); });
    q('audio-input').addEventListener('change', function(e){
      var file = e.target.files[0];
      if (!file) return;
      audioFile = file;
      audioEl.src = URL.createObjectURL(file);
      q('audio-name').textContent = file.name;
      var name = file.name.replace(/\.[^.]+$/, '').replace(/[-_]/g, ' ');
      q('song-title').value = name;
    });

    /* Drag & drop audio */
    var audioUpload = q('audio-upload');
    audioUpload.addEventListener('dragover', function(e){ e.preventDefault(); audioUpload.style.borderColor = 'rgba(var(--aura-color),0.5)'; });
    audioUpload.addEventListener('dragleave', function(){ audioUpload.style.borderColor = ''; });
    audioUpload.addEventListener('drop', function(e){
      e.preventDefault();
      audioUpload.style.borderColor = '';
      var file = e.dataTransfer.files[0];
      if (file && file.type.startsWith('audio/')) {
        audioFile = file;
        audioEl.src = URL.createObjectURL(file);
        q('audio-name').textContent = file.name;
        q('song-title').value = file.name.replace(/\.[^.]+$/, '').replace(/[-_]/g, ' ');
      }
    });

    /* Cover upload */
    q('cover-upload').addEventListener('click', function(){ q('cover-input').click(); });
    q('cover-input').addEventListener('change', function(e){
      var file = e.target.files[0];
      if (!file) return;
      var url = URL.createObjectURL(file);
      coverDisplay.innerHTML = '';
      coverDisplay.classList.remove('aura-ap-placeholder');
      var img = document.createElement('img');
      img.src = url;
      img.style.cssText = 'width:100%;height:100%;object-fit:cover;display:block;';
      img.alt = 'Cover art';
      coverDisplay.appendChild(img);
      q('cover-name').textContent = file.name;
    });

    /* Panel toggle */
    panelToggle.addEventListener('click', function(){
      panelToggle.classList.toggle('aura-ap-open');
      panelBody.classList.toggle('aura-ap-open');
    });

    /* Color pickers */
    qa('[data-aura="aura-colors"] .aura-ap-swatch').forEach(function(sw){
      sw.addEventListener('click', function(){
        qa('[data-aura="aura-colors"] .aura-ap-swatch').forEach(function(s){ s.classList.remove('aura-ap-selected'); });
        sw.classList.add('aura-ap-selected');
        root.style.setProperty('--aura-color', sw.getAttribute('data-c'));
      });
    });

    qa('[data-aura="border-colors"] .aura-ap-swatch').forEach(function(sw){
      sw.addEventListener('click', function(){
        qa('[data-aura="border-colors"] .aura-ap-swatch').forEach(function(s){ s.classList.remove('aura-ap-selected'); });
        sw.classList.add('aura-ap-selected');
        root.style.setProperty('--aura-border-color', sw.getAttribute('data-c'));
      });
    });

    /* Shape */
    qa('.aura-ap-shape-btn').forEach(function(btn){
      btn.addEventListener('click', function(){
        qa('.aura-ap-shape-btn').forEach(function(b){ b.classList.remove('aura-ap-selected'); });
        btn.classList.add('aura-ap-selected');
        var shape = btn.getAttribute('data-s');
        playerCard.className = 'aura-ap-card aura-ap-' + shape;
        cover3D.className    = 'aura-ap-cover-3d aura-ap-' + shape;
        reviewCard.className = 'aura-ap-review-card aura-ap-' + shape;
      });
    });

    /* Toggles */
    q('glow-toggle').addEventListener('click', function(){
      this.classList.toggle('aura-ap-on');
      glowEl.classList.toggle('aura-ap-hidden');
    });

    q('dl-toggle').addEventListener('click', function(){
      this.classList.toggle('aura-ap-on');
      downloadBtn.style.display = this.classList.contains('aura-ap-on') ? 'flex' : 'none';
    });

    q('review-toggle').addEventListener('click', function(){
      this.classList.toggle('aura-ap-on');
      reviewWrap.style.display = this.classList.contains('aura-ap-on') ? '' : 'none';
    });

    /* Background color picker */
    qa('[data-aura="bg-colors"] .aura-ap-swatch').forEach(function(sw){
      sw.addEventListener('click', function(){
        qa('[data-aura="bg-colors"] .aura-ap-swatch').forEach(function(s){ s.classList.remove('aura-ap-selected'); });
        sw.classList.add('aura-ap-selected');
        var bg = sw.getAttribute('data-bg');
        var mode = sw.getAttribute('data-mode');
        root.style.setProperty('--aura-page-bg', bg);
        if (mode === 'light') {
          root.classList.add('aura-ap-light');
          root.style.background = bg;
        } else {
          root.classList.remove('aura-ap-light');
          root.style.background = bg;
        }
      });
    });

    /* Notes toggle */
    q('notes-toggle').addEventListener('click', function(){
      this.classList.toggle('aura-ap-on');
      notesField.style.display = this.classList.contains('aura-ap-on') ? '' : 'none';
    });

    /* Download */
    downloadBtn.addEventListener('click', function(){
      if (!audioFile) return;
      var a = document.createElement('a');
      a.href = URL.createObjectURL(audioFile);
      a.download = audioFile.name;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    });

    /* Share */
    q('share-btn').addEventListener('click', function(){
      var title = q('song-title').value;
      var artist = q('song-artist').value;
      if (navigator.share) {
        navigator.share({ title: title, text: 'Check out "' + title + '" by ' + artist });
      } else {
        var dummy = document.createElement('textarea');
        dummy.value = 'Check out "' + title + '" by ' + artist;
        document.body.appendChild(dummy);
        dummy.select();
        document.execCommand('copy');
        document.body.removeChild(dummy);
        var btn = q('share-btn');
        var orig = btn.innerHTML;
        btn.textContent = 'Copied!';
        setTimeout(function(){ btn.innerHTML = orig; }, 1500);
      }
    });

    /* 3D tilt on cover */
    var coverWrap = q('cover-wrap');
    coverWrap.addEventListener('mousemove', function(e){
      var r = coverWrap.getBoundingClientRect();
      var x = (e.clientX - r.left) / r.width - 0.5;
      var y = (e.clientY - r.top) / r.height - 0.5;
      cover3D.style.transform = 'rotateX(' + (-y * 20) + 'deg) rotateY(' + (x * 20) + 'deg)';
    });
    coverWrap.addEventListener('mouseleave', function(){
      cover3D.style.transform = 'rotateX(6deg) rotateY(-4deg)';
    });

    /* Skip buttons */
    q('prev').addEventListener('click', function(){ audioEl.currentTime = Math.max(0, audioEl.currentTime - 15); });
    q('next').addEventListener('click', function(){ if (audioEl.duration) audioEl.currentTime = Math.min(audioEl.duration, audioEl.currentTime + 15); });

    /* === RADIATING MUSIC NOTES === */
    (function generateNotes(){
      var field = notesField;
      var noteSVGs = [
        '<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><ellipse cx="9" cy="19" rx="4" ry="3"/><line x1="13" y1="19" x2="13" y2="4"/></svg>',
        '<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><ellipse cx="8" cy="19" rx="4" ry="3"/><line x1="12" y1="19" x2="12" y2="4"/><path d="M12 4c3 0 5 2 6 5"/></svg>',
        '<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><ellipse cx="5" cy="19" rx="3" ry="2.5"/><ellipse cx="17" cy="17" rx="3" ry="2.5"/><line x1="8" y1="19" x2="8" y2="5"/><line x1="20" y1="17" x2="20" y2="3"/><line x1="8" y1="5" x2="20" y2="3"/></svg>',
        '<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><ellipse cx="5" cy="19" rx="3" ry="2.5"/><ellipse cx="17" cy="17" rx="3" ry="2.5"/><line x1="8" y1="19" x2="8" y2="5"/><line x1="20" y1="17" x2="20" y2="3"/><line x1="8" y1="5" x2="20" y2="3"/><line x1="8" y1="8" x2="20" y2="6"/></svg>',
        '<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M12 2c-1 4-5 6-5 10a5 5 0 0 0 8 4c2-2 1-5-1-5s-3 1-3 3"/><line x1="12" y1="2" x2="12" y2="22"/></svg>'
      ];
      var noteCount = 24;
      var angleStep = (Math.PI * 2) / noteCount;
      for (var i = 0; i < noteCount; i++) {
        var note = document.createElement('div');
        var isWhite = Math.random() > 0.35;
        note.className = 'aura-ap-note ' + (isWhite ? 'aura-ap-note--white' : 'aura-ap-note--black');
        note.innerHTML = noteSVGs[Math.floor(Math.random() * noteSVGs.length)];
        var angle = angleStep * i + (Math.random() - 0.5) * 0.8;
        var dist = 220 + Math.random() * 400;
        var tx = Math.cos(angle) * dist;
        var ty = Math.sin(angle) * dist;
        var size = 16 + Math.random() * 22;
        var dur = 7 + Math.random() * 9;
        var delay = Math.random() * dur;
        var rotStart = (Math.random() - 0.5) * 40;
        var rotEnd = rotStart + (Math.random() - 0.5) * 60;
        var endScale = 0.7 + Math.random() * 0.6;
        var peak = isWhite ? (0.45 + Math.random() * 0.35) : (0.25 + Math.random() * 0.2);
        note.style.setProperty('--note-tx', tx + 'px');
        note.style.setProperty('--note-ty', ty + 'px');
        note.style.setProperty('--note-size', size + 'px');
        note.style.setProperty('--note-dur', dur + 's');
        note.style.setProperty('--note-delay', delay + 's');
        note.style.setProperty('--note-rot', rotStart + 'deg');
        note.style.setProperty('--note-rot-end', rotEnd + 'deg');
        note.style.setProperty('--note-end-scale', endScale);
        note.style.setProperty('--note-peak', peak);
        field.appendChild(note);
      }
    })();
  }

  /* Initialize all Aura Player instances on the page */
  function initAll() {
    document.querySelectorAll('.aura-ap[data-aura-instance]').forEach(function(el) {
      if (!el.dataset.auraInit) {
        el.dataset.auraInit = '1';
        initAuraPlayer(el);
      }
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAll);
  } else {
    initAll();
  }
})();
