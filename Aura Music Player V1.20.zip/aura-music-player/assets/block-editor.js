( function( blocks, element, blockEditor, components, i18n ) {
    var el = element.createElement;
    var InspectorControls = blockEditor.InspectorControls;
    var MediaUpload = blockEditor.MediaUpload;
    var PanelBody = components.PanelBody;
    var TextControl = components.TextControl;
    var Button = components.Button;
    var __ = i18n.__;

    blocks.registerBlockType( 'aura/music-player', {

        title: __( 'Aura Music Player', 'aura-music-player' ),
        description: __( 'A beautiful 3D music player with visualizer, cover art, and customizable colors.', 'aura-music-player' ),
        icon: el( 'svg', { viewBox: '0 0 24 24', xmlns: 'http://www.w3.org/2000/svg' },
            el( 'path', { d: 'M9 18V5l12-2v13M6 18a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM18 16a3 3 0 1 0 0-6 3 3 0 0 0 0 6z', fill: 'none', stroke: 'currentColor', strokeWidth: '2', strokeLinecap: 'round', strokeLinejoin: 'round' } )
        ),
        category: 'media',
        keywords: [ __( 'music' ), __( 'audio' ), __( 'player' ), __( 'aura' ) ],
        supports: {
            align: [ 'wide', 'full' ],
            html: false,
        },

        attributes: {
            title:  { type: 'string', default: 'Untitled Track' },
            artist: { type: 'string', default: 'Unknown Artist' },
            src:    { type: 'string', default: '' },
            cover:  { type: 'string', default: '' },
        },

        edit: function( props ) {
            var atts = props.attributes;
            var setAtts = props.setAttributes;

            return el( element.Fragment, {},

                /* ── Sidebar Inspector Controls ── */
                el( InspectorControls, {},
                    el( PanelBody, { title: __( 'Track Settings', 'aura-music-player' ), initialOpen: true },
                        el( TextControl, {
                            label: __( 'Song Title', 'aura-music-player' ),
                            value: atts.title,
                            onChange: function( val ) { setAtts( { title: val } ); },
                        } ),
                        el( TextControl, {
                            label: __( 'Artist Name', 'aura-music-player' ),
                            value: atts.artist,
                            onChange: function( val ) { setAtts( { artist: val } ); },
                        } )
                    ),
                    el( PanelBody, { title: __( 'Audio File', 'aura-music-player' ), initialOpen: true },
                        el( MediaUpload, {
                            onSelect: function( media ) { setAtts( { src: media.url } ); },
                            allowedTypes: [ 'audio' ],
                            render: function( obj ) {
                                return el( 'div', {},
                                    atts.src
                                        ? el( 'div', { className: 'aura-mp-editor-file' },
                                            el( 'span', {}, '🎵 ' + atts.src.split('/').pop() ),
                                            el( Button, {
                                                isDestructive: true,
                                                isSmall: true,
                                                onClick: function() { setAtts( { src: '' } ); },
                                                style: { marginLeft: '8px' },
                                            }, __( 'Remove' ) )
                                          )
                                        : null,
                                    el( Button, {
                                        isPrimary: !atts.src,
                                        isSecondary: !!atts.src,
                                        onClick: obj.open,
                                        style: { marginTop: '8px' },
                                    }, atts.src ? __( 'Replace Audio', 'aura-music-player' ) : __( 'Select Audio File', 'aura-music-player' ) )
                                );
                            },
                        } )
                    ),
                    el( PanelBody, { title: __( 'Cover Art', 'aura-music-player' ), initialOpen: true },
                        el( MediaUpload, {
                            onSelect: function( media ) { setAtts( { cover: media.url } ); },
                            allowedTypes: [ 'image' ],
                            render: function( obj ) {
                                return el( 'div', {},
                                    atts.cover
                                        ? el( 'div', {},
                                            el( 'img', { src: atts.cover, style: { maxWidth: '100%', borderRadius: '8px', marginBottom: '8px' } } ),
                                            el( Button, {
                                                isDestructive: true,
                                                isSmall: true,
                                                onClick: function() { setAtts( { cover: '' } ); },
                                            }, __( 'Remove' ) )
                                          )
                                        : null,
                                    el( Button, {
                                        isPrimary: !atts.cover,
                                        isSecondary: !!atts.cover,
                                        onClick: obj.open,
                                        style: { marginTop: '4px' },
                                    }, atts.cover ? __( 'Replace Image', 'aura-music-player' ) : __( 'Select Cover Image', 'aura-music-player' ) )
                                );
                            },
                        } )
                    )
                ),

                /* ── Editor Preview Placeholder ── */
                el( 'div', { className: 'aura-mp-editor-preview' },
                    el( 'div', { className: 'aura-mp-editor-icon' },
                        atts.cover
                            ? el( 'img', { src: atts.cover, alt: 'Cover' } )
                            : el( 'span', {}, '🎵' )
                    ),
                    el( 'div', { className: 'aura-mp-editor-info' },
                        el( 'div', { className: 'aura-mp-editor-title' }, atts.title || 'Untitled Track' ),
                        el( 'div', { className: 'aura-mp-editor-artist' }, atts.artist || 'Unknown Artist' ),
                        atts.src
                            ? el( 'div', { className: 'aura-mp-editor-src' }, '🔊 ' + atts.src.split('/').pop() )
                            : el( 'div', { className: 'aura-mp-editor-src aura-mp-editor-nosrc' }, 'No audio file selected — add one in the sidebar →' )
                    )
                )
            );
        },

        save: function() {
            // Server-side rendered — return null
            return null;
        },
    } );

} )( window.wp.blocks, window.wp.element, window.wp.blockEditor, window.wp.components, window.wp.i18n );
