<?php
/**
 * Plugin Name: Aura Music Player
 * Plugin URI:  https://example.com/aura-music-player
 * Description: A beautiful, customizable 3D music player with visualizer, cover art, and review box. Add via the block editor or shortcode [aura_player].
 * Version:     1.30
 * Author:      Robert Shultz
 * License:     GPL-2.0-or-later
 * Text Domain: aura-music-player
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'AURA_MP_VERSION', '1.30' );
define( 'AURA_MP_URL', plugin_dir_url( __FILE__ ) );
define( 'AURA_MP_PATH', plugin_dir_path( __FILE__ ) );

/* ─────────────────────────────────────────────
   1. REGISTER FRONT-END ASSETS
   ───────────────────────────────────────────── */

function aura_mp_register_assets() {
    wp_register_style(
        'aura-mp-fonts',
        'https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&family=Sora:wght@300;400;500;600;700&display=swap',
        array(),
        null
    );
    wp_register_style(
        'aura-mp-style',
        AURA_MP_URL . 'assets/aura-music-player.css',
        array( 'aura-mp-fonts' ),
        AURA_MP_VERSION
    );
    wp_register_script(
        'aura-mp-script',
        AURA_MP_URL . 'assets/aura-music-player.js',
        array(),
        AURA_MP_VERSION,
        true
    );
}
add_action( 'wp_enqueue_scripts', 'aura_mp_register_assets' );
add_action( 'enqueue_block_assets', 'aura_mp_register_assets' );

/* ─────────────────────────────────────────────
   2. GUTENBERG BLOCK
   ───────────────────────────────────────────── */

function aura_mp_register_block() {
    wp_register_script(
        'aura-mp-block-editor',
        AURA_MP_URL . 'assets/block-editor.js',
        array( 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-i18n' ),
        AURA_MP_VERSION,
        true
    );

    wp_register_style(
        'aura-mp-block-editor-style',
        AURA_MP_URL . 'assets/block-editor.css',
        array(),
        AURA_MP_VERSION
    );

    register_block_type( 'aura/music-player', array(
        'editor_script'   => 'aura-mp-block-editor',
        'editor_style'    => 'aura-mp-block-editor-style',
        'style'           => 'aura-mp-style',
        'script'          => 'aura-mp-script',
        'attributes'      => array(
            'title'  => array( 'type' => 'string', 'default' => 'Untitled Track' ),
            'artist' => array( 'type' => 'string', 'default' => 'Unknown Artist' ),
            'src'    => array( 'type' => 'string', 'default' => '' ),
            'cover'  => array( 'type' => 'string', 'default' => '' ),
        ),
        'render_callback' => 'aura_mp_render',
    ) );
}
add_action( 'init', 'aura_mp_register_block' );

/* ─────────────────────────────────────────────
   3. SHARED RENDER (block + shortcode)
   ───────────────────────────────────────────── */

function aura_mp_render( $atts ) {
    $atts = wp_parse_args( $atts, array(
        'title'  => 'Untitled Track',
        'artist' => 'Unknown Artist',
        'src'    => '',
        'cover'  => '',
    ) );

    $title  = esc_attr( $atts['title'] );
    $artist = esc_attr( $atts['artist'] );
    $src    = esc_url( $atts['src'] );
    $cover  = esc_url( $atts['cover'] );

    wp_enqueue_style( 'aura-mp-fonts' );
    wp_enqueue_style( 'aura-mp-style' );
    wp_enqueue_script( 'aura-mp-script' );

    static $instance = 0;
    $instance++;
    $id = 'aura-ap-root-' . $instance;

    if ( $cover ) {
        $cover_html  = '<img src="' . $cover . '" alt="Cover art" style="width:100%;height:100%;object-fit:cover;display:block;">';
        $cover_class = '';
    } else {
        $cover_html  = '<span class="aura-ap-icon">&#127925;</span>';
        $cover_class = 'aura-ap-placeholder';
    }

    $audio_src = $src ? ' src="' . $src . '"' : '';

    ob_start();
    ?>
<div class="aura-ap" id="<?php echo esc_attr( $id ); ?>" data-aura-instance="<?php echo $instance; ?>">

  <div class="aura-ap-glow" data-aura="glow"></div>
  <div class="aura-ap-notes-field" data-aura="notes-field"></div>

  <div class="aura-ap-container">

    <div class="aura-ap-cover-wrap" data-aura="cover-wrap">
      <div class="aura-ap-cover-3d aura-ap-rounded" data-aura="cover3d">
        <div class="aura-ap-cover-face">
          <div class="<?php echo esc_attr( $cover_class ); ?>" data-aura="cover-display"><?php echo $cover_html; ?></div>
        </div>
        <div class="aura-ap-reflect"></div>
      </div>
    </div>

    <div class="aura-ap-card-wrap">
      <div class="aura-ap-card aura-ap-rounded" data-aura="card">

        <div class="aura-ap-song-info">
          <input class="aura-ap-editable aura-ap-title-input" data-aura="song-title" value="<?php echo $title; ?>" maxlength="60" spellcheck="false" aria-label="Song title">
          <input class="aura-ap-editable aura-ap-artist-input" data-aura="song-artist" value="<?php echo $artist; ?>" maxlength="40" spellcheck="false" aria-label="Artist name">
        </div>

        <div class="aura-ap-visualizer" data-aura="visualizer"></div>

        <div class="aura-ap-progress-section">
          <div class="aura-ap-progress-track" data-aura="progress-track">
            <div class="aura-ap-progress-fill" data-aura="progress-fill"></div>
          </div>
          <div class="aura-ap-time-display">
            <span data-aura="cur-time">0:00</span>
            <span data-aura="tot-time">0:00</span>
          </div>
        </div>

        <div class="aura-ap-controls">
          <button class="aura-ap-ctrl-btn" data-aura="shuffle" aria-label="Shuffle"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 3 21 3 21 8"/><line x1="4" y1="20" x2="21" y2="3"/><polyline points="21 16 21 21 16 21"/><line x1="15" y1="15" x2="21" y2="21"/><line x1="4" y1="4" x2="9" y2="9"/></svg></button>
          <button class="aura-ap-ctrl-btn" data-aura="prev" aria-label="Previous"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="19 20 9 12 19 4 19 20"/><line x1="5" y1="19" x2="5" y2="5"/></svg></button>
          <button class="aura-ap-play-btn" data-aura="play" aria-label="Play"><svg viewBox="0 0 24 24" fill="currentColor" data-aura="play-icon"><polygon points="6 3 20 12 6 21 6 3"/></svg></button>
          <button class="aura-ap-ctrl-btn" data-aura="next" aria-label="Next"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 4 15 12 5 20 5 4"/><line x1="19" y1="5" x2="19" y2="19"/></svg></button>
          <button class="aura-ap-ctrl-btn" data-aura="repeat" aria-label="Repeat"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg></button>
        </div>

        <div class="aura-ap-volume">
          <button class="aura-ap-ctrl-btn" data-aura="mute" aria-label="Mute"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" data-aura="vol-icon"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/></svg></button>
          <div class="aura-ap-vol-track" data-aura="vol-track">
            <div class="aura-ap-vol-fill" data-aura="vol-fill"></div>
          </div>
        </div>

        <div class="aura-ap-extras">
          <button class="aura-ap-extra-btn" data-aura="download-btn" style="display:none" aria-label="Download"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> Download</button>
          <button class="aura-ap-extra-btn" data-aura="share-btn" aria-label="Share"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg> Share</button>
        </div>
      </div>
    </div>

    <div class="aura-ap-review-wrap" data-aura="review-wrap">
      <div class="aura-ap-review-card aura-ap-rounded" data-aura="review-card">
        <textarea class="aura-ap-review-textarea" data-aura="review-text" maxlength="1000" placeholder="Write your thoughts about this track…" aria-label="Review text" spellcheck="true"></textarea>
      </div>
    </div>

    <div class="aura-ap-customize">
      <button class="aura-ap-panel-toggle" data-aura="panel-toggle"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg> Customize</button>
      <div class="aura-ap-panel-body" data-aura="panel-body">
        <div class="aura-ap-panel-inner">

          <div class="aura-ap-ctrl-group"><label>Audio File</label>
            <div class="aura-ap-upload" data-aura="audio-upload"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg><p data-aura="audio-name">Drop or click to add audio</p><p class="aura-ap-hint">MP3, WAV, OGG, FLAC</p><input type="file" data-aura="audio-input" accept="audio/*" style="display:none"></div>
          </div>

          <div class="aura-ap-ctrl-group"><label>Cover Art</label>
            <div class="aura-ap-cover-upload" data-aura="cover-upload"><p data-aura="cover-name">Drop or click to add cover image</p><input type="file" data-aura="cover-input" accept="image/*" style="display:none"></div>
          </div>

          <div class="aura-ap-ctrl-group"><label>Aura Color</label>
            <div class="aura-ap-colors" data-aura="aura-colors">
              <button class="aura-ap-swatch aura-ap-selected" data-c="255,240,220" style="background:rgb(255,240,220)" aria-label="Warm White"></button>
              <button class="aura-ap-swatch" data-c="255,140,105" style="background:rgb(255,140,105)" aria-label="Coral"></button>
              <button class="aura-ap-swatch" data-c="140,180,255" style="background:rgb(140,180,255)" aria-label="Sky Blue"></button>
              <button class="aura-ap-swatch" data-c="180,140,255" style="background:rgb(180,140,255)" aria-label="Lavender"></button>
              <button class="aura-ap-swatch" data-c="140,255,180" style="background:rgb(140,255,180)" aria-label="Mint"></button>
              <button class="aura-ap-swatch" data-c="255,220,100" style="background:rgb(255,220,100)" aria-label="Gold"></button>
              <button class="aura-ap-swatch" data-c="255,160,200" style="background:rgb(255,160,200)" aria-label="Rose"></button>
              <button class="aura-ap-swatch" data-c="100,220,220" style="background:rgb(100,220,220)" aria-label="Teal"></button>
            </div>
          </div>

          <div class="aura-ap-ctrl-group"><label>Border Color</label>
            <div class="aura-ap-colors" data-aura="border-colors">
              <button class="aura-ap-swatch aura-ap-selected" data-c="20,20,20" style="background:rgb(20,20,20);border-color:rgba(255,255,255,0.2)" aria-label="Black"></button>
              <button class="aura-ap-swatch" data-c="80,80,80" style="background:rgb(80,80,80)" aria-label="Charcoal"></button>
              <button class="aura-ap-swatch" data-c="180,180,180" style="background:rgb(180,180,180)" aria-label="Silver"></button>
              <button class="aura-ap-swatch" data-c="120,80,40" style="background:rgb(120,80,40)" aria-label="Bronze"></button>
              <button class="aura-ap-swatch" data-c="60,60,100" style="background:rgb(60,60,100)" aria-label="Midnight"></button>
              <button class="aura-ap-swatch" data-c="40,80,60" style="background:rgb(40,80,60)" aria-label="Forest"></button>
            </div>
          </div>

          <div class="aura-ap-ctrl-group"><label>Player Shape</label>
            <div class="aura-ap-shapes">
              <button class="aura-ap-shape-btn aura-ap-selected" data-s="rounded">Rounded</button>
              <button class="aura-ap-shape-btn" data-s="square">Square</button>
              <button class="aura-ap-shape-btn" data-s="pill">Pill</button>
            </div>
          </div>

          <div class="aura-ap-ctrl-group"><div class="aura-ap-toggle-row"><label>Aura Glow</label><button class="aura-ap-toggle aura-ap-on" data-aura="glow-toggle" aria-label="Toggle aura glow"><span class="aura-ap-toggle-knob"></span></button></div></div>
          <div class="aura-ap-ctrl-group"><div class="aura-ap-toggle-row"><label>Allow Download</label><button class="aura-ap-toggle" data-aura="dl-toggle" aria-label="Toggle download"><span class="aura-ap-toggle-knob"></span></button></div></div>
          <div class="aura-ap-ctrl-group"><div class="aura-ap-toggle-row"><label>Review Box</label><button class="aura-ap-toggle aura-ap-on" data-aura="review-toggle" aria-label="Toggle review box"><span class="aura-ap-toggle-knob"></span></button></div></div>

          <div class="aura-ap-ctrl-group"><label>Page Background</label>
            <div class="aura-ap-colors" data-aura="bg-colors">
              <button class="aura-ap-swatch aura-ap-selected" data-bg="#0a0a0f" data-mode="dark" style="background:#0a0a0f;border:1px solid rgba(255,255,255,0.2)" aria-label="Near Black"></button>
              <button class="aura-ap-swatch" data-bg="#151520" data-mode="dark" style="background:#151520;border:1px solid rgba(255,255,255,0.15)" aria-label="Dark Navy"></button>
              <button class="aura-ap-swatch" data-bg="#1a1a2e" data-mode="dark" style="background:#1a1a2e;border:1px solid rgba(255,255,255,0.15)" aria-label="Deep Indigo"></button>
              <button class="aura-ap-swatch" data-bg="#f5f5f5" data-mode="light" style="background:#f5f5f5" aria-label="Light Gray"></button>
              <button class="aura-ap-swatch" data-bg="#ffffff" data-mode="light" style="background:#ffffff" aria-label="White"></button>
              <button class="aura-ap-swatch" data-bg="#faf8f2" data-mode="light" style="background:#faf8f2" aria-label="Cream"></button>
            </div>
          </div>

          <div class="aura-ap-ctrl-group"><div class="aura-ap-toggle-row"><label>Music Notes</label><button class="aura-ap-toggle aura-ap-on" data-aura="notes-toggle" aria-label="Toggle music notes"><span class="aura-ap-toggle-knob"></span></button></div></div>

        </div>
      </div>
    </div>

  </div>
  <audio data-aura="audio" preload="metadata"<?php echo $audio_src; ?>></audio>
</div>
    <?php
    return ob_get_clean();
}

/* ─────────────────────────────────────────────
   4. SHORTCODE (backward compatibility)
   ───────────────────────────────────────────── */

function aura_mp_shortcode( $atts ) {
    return aura_mp_render( shortcode_atts( array(
        'title'  => 'Untitled Track',
        'artist' => 'Unknown Artist',
        'src'    => '',
        'cover'  => '',
    ), $atts, 'aura_player' ) );
}
add_shortcode( 'aura_player', 'aura_mp_shortcode' );
